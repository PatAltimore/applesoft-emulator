10 A = 0 : B = 1
20 FOR I = 1 TO 15
30 PRINT A;
40 C = A + B
50 A = B : B = C
60 NEXT I
70 PRINT
